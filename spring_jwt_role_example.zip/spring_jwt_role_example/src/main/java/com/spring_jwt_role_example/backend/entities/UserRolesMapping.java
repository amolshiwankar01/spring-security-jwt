package com.spring_jwt_role_example.backend.entities;


import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

import javax.persistence.*;

@Entity
@Table(name = "user_roles_mapping")
@IdClass(UserRolesMappingEmbedded.class)
@Slf4j
@Getter
@Setter
public class UserRolesMapping {

    @ManyToOne
    @Id
    @JoinColumn(name = "user_id", referencedColumnName = "user_id")
    User user;

    @ManyToOne
    @Id
    @JoinColumn(name = "role_id", referencedColumnName = "role_id")
    Role role;
}
