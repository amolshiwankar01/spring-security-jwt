package com.spring_jwt_role_example.backend.entities;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LoginUser {

    private String username;
    private String password;
    private String email;
    private String firstName;
    private String lastName;

}

