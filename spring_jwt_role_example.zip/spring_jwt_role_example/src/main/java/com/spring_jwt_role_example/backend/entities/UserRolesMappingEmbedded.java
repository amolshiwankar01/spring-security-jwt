package com.spring_jwt_role_example.backend.entities;

import java.io.Serializable;

public class UserRolesMappingEmbedded implements Serializable {

    private Integer user;
    private Integer role;
}
