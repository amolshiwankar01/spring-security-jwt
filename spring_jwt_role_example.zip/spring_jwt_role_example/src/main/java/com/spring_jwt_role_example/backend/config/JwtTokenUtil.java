package com.spring_jwt_role_example.backend.config;

import com.spring_jwt_role_example.backend.entities.User;
import com.spring_jwt_role_example.backend.entities.UserRolesMapping;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.function.Function;

@Component
public class JwtTokenUtil implements Serializable {


    @Value("${SIGNING_KEY}")
    String signingKey;

    @Value("${ACCESS_TOKEN_VALIDITY_MILLISECONDS}")
    String accessTokenValiditySeconds;

    public String getUsernameFromToken(String token) {
        return getClaimFromToken(token, Claims::getSubject);
    }

    public Date getExpirationDateFromToken(String token) {
        return getClaimFromToken(token, Claims::getExpiration);
    }

    public <T> T getClaimFromToken(String token, Function<Claims, T> claimsResolver) {
        final Claims claims = getAllClaimsFromToken(token);
        return claimsResolver.apply(claims);
    }

    private Claims getAllClaimsFromToken(String token) {
        return Jwts.parser()
                .setSigningKey(signingKey)
                .parseClaimsJws(token)
                .getBody();
    }

    private Boolean isTokenExpired(String token) {
        final Date expiration = getExpirationDateFromToken(token);
        return expiration.before(new Date());
    }

    public String generateToken(User user, List<UserRolesMapping> userRolesMappings) {
        return doGenerateToken(user, userRolesMappings);
    }

    private String doGenerateToken(User user,  List<UserRolesMapping> userRolesMappings ) {
        Long accessTokenLimit = Long.parseLong(accessTokenValiditySeconds);
        if(!StringUtils.isEmpty(accessTokenValiditySeconds) ){
            accessTokenLimit = Long.parseLong(accessTokenValiditySeconds);
        }

       /**/
        Claims claims = Jwts.claims().setSubject(user.getUsername());
        List<GrantedAuthority> grantedAuthorities = new ArrayList<>();
        for ( UserRolesMapping userRolesMapping : userRolesMappings ) {
            grantedAuthorities.addAll(AuthorityUtils.commaSeparatedStringToAuthorityList(userRolesMapping.getRole().getRole()));
        }
        claims.put("scopes", grantedAuthorities);

        return Jwts.builder()
                .setClaims(claims)
                .setIssuer("http://devglan.com")
                .setIssuedAt(new Date(System.currentTimeMillis()))
                .setExpiration(new Date(System.currentTimeMillis() + accessTokenLimit*1000))
                .signWith(SignatureAlgorithm.HS256, signingKey)
                .compact();
    }

    public Boolean validateToken(String token, UserDetails userDetails) {
        final String username = getUsernameFromToken(token);
        return (
                username.equals(userDetails.getUsername())
                        && !isTokenExpired(token));
    }

}
