package com.spring_jwt_role_example.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringJwtRoleExampleApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringJwtRoleExampleApplication.class, args);
    }

}
