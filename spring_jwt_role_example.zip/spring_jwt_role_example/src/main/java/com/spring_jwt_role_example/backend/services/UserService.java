package com.spring_jwt_role_example.backend.services;

import com.spring_jwt_role_example.backend.entities.*;
import com.spring_jwt_role_example.backend.repo.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import javax.naming.AuthenticationException;
import java.util.List;

@RestController
@RequestMapping("/user")
public class UserService {

    @Autowired
    UserRepository userRepository;

    @GetMapping
    public ApiResponse<List<User>> listUser(){
        return new ApiResponse<>(HttpStatus.OK.value(), "User list fetched successfully.","");
    }
}
