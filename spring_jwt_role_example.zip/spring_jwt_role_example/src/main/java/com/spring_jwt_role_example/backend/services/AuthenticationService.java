package com.spring_jwt_role_example.backend.services;


import com.spring_jwt_role_example.backend.config.JwtTokenUtil;
import com.spring_jwt_role_example.backend.entities.*;
import com.spring_jwt_role_example.backend.repo.UserRepository;
import com.spring_jwt_role_example.backend.repo.UserRolesMappingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.web.bind.annotation.*;

import javax.naming.AuthenticationException;
import java.util.List;

@RestController
@RequestMapping("/token")
public class AuthenticationService {

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private JwtTokenUtil jwtTokenUtil;

    @Autowired
    UserRepository userRepository;

    @Autowired
    UserRolesMappingRepository userRolesMappingRepository;


    @PostMapping("generate-token")
    public ApiResponse<AuthToken> register(@RequestBody LoginUser loginUser) throws AuthenticationException {
        //authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(loginUser.getUsername(), loginUser.getPassword()));
        User user = userRepository.findFirstByUsername(loginUser.getUsername());
        List<UserRolesMapping> userRolesMappings = userRolesMappingRepository.findAllByUser(user);
        String token = jwtTokenUtil.generateToken(user,userRolesMappings);
        return new ApiResponse<>(200, "success",new AuthToken(token, user.getUsername()));
    }

}


