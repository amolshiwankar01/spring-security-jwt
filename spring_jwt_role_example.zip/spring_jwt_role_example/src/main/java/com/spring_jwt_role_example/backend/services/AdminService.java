package com.spring_jwt_role_example.backend.services;

import com.spring_jwt_role_example.backend.entities.ApiResponse;
import com.spring_jwt_role_example.backend.entities.User;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/admin")
public class AdminService {

    @GetMapping
    public ApiResponse<List<User>> listUser(){
        return new ApiResponse<>(HttpStatus.OK.value(), "admin list fetched successfully.","");
    }

}
