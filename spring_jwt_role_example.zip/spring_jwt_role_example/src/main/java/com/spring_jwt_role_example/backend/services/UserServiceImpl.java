package com.spring_jwt_role_example.backend.services;

import com.spring_jwt_role_example.backend.entities.User;
import com.spring_jwt_role_example.backend.entities.UserRolesMapping;
import com.spring_jwt_role_example.backend.repo.UserRepository;
import com.spring_jwt_role_example.backend.repo.UserRolesMappingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service(value = "userServiceImpl")
public class UserServiceImpl implements UserDetailsService {

    @Autowired
    private UserRepository ucpUserRepository;

    @Autowired
    private UserRolesMappingRepository userRolesMappingRepository;

    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        User user = ucpUserRepository.findFirstByUsername(username);
        if(user == null){
            throw new UsernameNotFoundException("Invalid username or password.");
        }
        List<GrantedAuthority> grantedAuthorities = new ArrayList<>();
        List<UserRolesMapping> userRolesMappings = userRolesMappingRepository.findAllByUser(user);
        for ( UserRolesMapping userRolesMapping : userRolesMappings ) {
            grantedAuthorities.addAll(AuthorityUtils.commaSeparatedStringToAuthorityList(userRolesMapping.getRole().getRole()));
        }
        return new org.springframework.security.core.userdetails.User(user.getUsername(), user.getPassword()==null?"":user.getPassword(), grantedAuthorities);
    }

}
