package com.spring_jwt_role_example.backend.services;


import com.spring_jwt_role_example.backend.entities.ApiResponse;
import com.spring_jwt_role_example.backend.entities.AuthToken;
import com.spring_jwt_role_example.backend.entities.LoginUser;
import com.spring_jwt_role_example.backend.entities.User;
import com.spring_jwt_role_example.backend.repo.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.naming.AuthenticationException;

@RestController
@RequestMapping("/signup")
public class RegisterService {

    @Autowired
    UserRepository userRepository;

    @PostMapping
    public ApiResponse<AuthToken> register111(@RequestBody LoginUser loginUser) throws AuthenticationException {
        User user = new User();
        user.setEmail(loginUser.getEmail());
        user.setUsername(loginUser.getUsername());
        user.setPassword(loginUser.getPassword());
        user.setFirstName(loginUser.getFirstName());
        user.setLastName(loginUser.getLastName());
        userRepository.save(user);
        return new ApiResponse<>(200, "success",new AuthToken("", user.getUsername()));
    }
}
