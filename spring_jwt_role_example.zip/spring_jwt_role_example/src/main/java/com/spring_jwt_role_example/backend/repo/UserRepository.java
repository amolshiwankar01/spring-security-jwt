package com.spring_jwt_role_example.backend.repo;

import com.spring_jwt_role_example.backend.entities.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository extends JpaRepository<User,Integer> {
    User findFirstByUsername(String username);
}
