package com.spring_jwt_role_example.backend.repo;

import com.spring_jwt_role_example.backend.entities.User;
import com.spring_jwt_role_example.backend.entities.UserRolesMapping;
import com.spring_jwt_role_example.backend.entities.UserRolesMappingEmbedded;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserRolesMappingRepository extends JpaRepository<UserRolesMapping, UserRolesMappingEmbedded> {

    List<UserRolesMapping> findAllByUser(User user );
}