package com.spring_jwt_role_example.backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringJwtRoleExampleApplicationTests {

    @Test
    void contextLoads() {
    }

}
